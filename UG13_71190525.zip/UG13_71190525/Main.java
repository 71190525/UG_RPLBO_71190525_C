 import java.util.*;

class Pasien {
	String nama, alamat, penyakit;
	int usia, levelPenyakit;
	boolean status = false;

	Pasien (String nama, int usia, String alamat, String penyakit, int levelPenyakit) {
		this.nama = nama;
		this.usia = usia;
		this.alamat = alamat;
		this.penyakit = penyakit;
		this.levelPenyakit = levelPenyakit;
		this.status = status;
	}

	int getLevelPenyakit() {
		return this.levelPenyakit;
	}
}



class Dokter {
	String nama, spesiallis, ruangan;

	Dokter (String nama, String spesiallis, String ruangan) {
		this.nama = nama;
		this.spesiallis = spesiallis;
		this.ruangan = ruangan;
	}

	int memeriksa(Pasien pasien, Jadwal jadwal) {
		if (pasien.levelPenyakit < 1) {
			return 0;
		}
		return pasien.levelPenyakit-1;
	}

	void cekStatus(Pasien pasien) {
		if (pasien.levelPenyakit > 0) {
			System.out.println("======================PASIEN ANDA MASIH SAKIT======================");
			System.out.println();
		} else {
			System.out.println("======================SELAMAT PASIEN ANDA SUDAH SEMBUH DAN SEHAT======================");
			System.out.println();
		}
	}
}


class Suster {
	String nama;

	Suster (String nama) {
		this.nama = nama;
	}

	void screening(Pasien pasien, Jadwal jadwal) {}
}


class Pelayanan {
	String nama;

	Pelayanan (String nama) {
		this.nama = nama;
	}

	boolean mengaturJadwal(Pasien pasien, Dokter dokter, Jadwal jadwal) {
		if (pasien.levelPenyakit < 1) {
			System.out.println("======================Pasien Tidak Sakit Pengaturan Jadwal Dibatalkan======================");
			System.out.println();
			return false;
		}
		System.out.println("======================Proses Pengaturan Jadwal Berhasil======================");
		System.out.println();
		return true;
	}

	Pasien registrasi(String nama, int usia, String alamat, String penyakit, int levelPenyakit) {
		Pasien pasien = new Pasien(nama, usia, alamat, penyakit, levelPenyakit);
		System.out.println("======================Proses Regristrasi Berhasil======================");
		System.out.println();
		return pasien;
	}
}


class Jadwal {
	Pasien pasien;
	Dokter dokter;
	Suster suster;
	Pelayanan pelayanan;
	boolean statusDaftar = false;
	boolean statusScreening = false;

	Jadwal (Pasien pasien, Dokter dokter, Suster suster, Pelayanan pelayanan) {
		this.pasien = pasien;
		this.dokter = dokter;
		this.suster = suster;
		this.pelayanan = pelayanan;
	}
}



public class Main {
	public static void main(String[] args) {
		System.out.println("===========================================PROSESINISIALISASI============================================");
		Scanner reader = new Scanner(System.in);

		System.out.println();
		System.out.print("Masukkan nama anda : ");
		String nama = System.console().readLine();
		System.out.print("Masukkan usia anda : ");
		int usia = reader.nextInt();
		System.out.print("Masukkan alamat anda : ");
		String alamat = System.console().readLine();
		System.out.print("Masukkan penyakit anda : ");
		String penyakit = System.console().readLine();
		System.out.println();

		Pelayanan pelayanan = new Pelayanan("Ratih");
		Pasien pasien = pelayanan.registrasi(nama, usia, alamat, penyakit, 2);
		Dokter dokter = new Dokter("Budi", "Organ Dalam", "A123");
		Suster suster = new Suster("Siti");
		Jadwal jadwal = new Jadwal(pasien, dokter, suster, pelayanan);
		boolean berhasil = pelayanan.mengaturJadwal(pasien, dokter, jadwal);
		System.out.println("===========================================PROSES UJI COBA PASIEN DAN JADWAL ILLEGAL============================================");
		System.out.println();
		if (berhasil) {
			System.out.println("===========================================PROSES SCREENING SUSTER============================================");
			System.out.println();
			suster.screening(pasien, jadwal);
			System.out.println("===========================================PROSES SCREENING SUSTER BERHASIL============================================");
			System.out.println();
			System.out.println("===========================================PROSES PEMERIKSAAN DOKTER============================================");
			System.out.println();

			int x = pasien.getLevelPenyakit();
			for(int i = 0; i <= x; i++) {
				int levelPenyakit = dokter.memeriksa(pasien, jadwal);
				pasien.levelPenyakit = levelPenyakit;
				dokter.cekStatus(pasien);
				if (levelPenyakit < 1) {
					pasien.status = true;
					break;
				}
			}

			System.out.println("===========================================PROSES PEMERIKSAAN DOKTER BERHASIL============================================");
			System.out.println();
			System.out.println(pasien.status);
			System.out.println(pasien.levelPenyakit);
		}


	}
}